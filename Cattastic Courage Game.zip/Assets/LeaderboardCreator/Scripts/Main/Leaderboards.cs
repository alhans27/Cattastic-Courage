namespace Dan.Main
{
    public static class Leaderboards
    {
        public static LeaderboardReference DemoSceneLeaderboard = new LeaderboardReference("980324f10e2f03fc0fd6a38a70f88123919a6aed35a4aea86211ad58b68db9c4");
        public static LeaderboardReference Cattastic_Courage_Leaderboard = new LeaderboardReference("226a36fa578ed1be200eff0bdcf75b2484ee9f6845f55f3ed8e75c85dbb604c2");
    }
}
