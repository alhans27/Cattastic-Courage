using UnityEngine;

public class Storage : MonoBehaviour
{
    public static string playerName = "Default Player";

    public static int saveLevel = 2;
    public static int highScore = 0;
}
